https://stugedikedutr-my.sharepoint.com/:p:/g/personal/221041040_stu_gedik_edu_tr/EQqjQXNMUHhLts75qDesLwIBkG7iTThYgP2rVpXdJWgYcQ?e=9mbiR2
